import re
import time
import os
import gc
import numpy as np
import pandas as pd
import torch
import nltk
import spacy
import random
from tqdm import tqdm
from nltk.corpus import stopwords
from nltk import WordNetLemmatizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import precision_score, recall_score, f1_score
from sentence_transformers import SentenceTransformer

# ==================== 1. 环境与路径配置 ====================
# 设置 NLTK 数据路径
nltk_data_path = "nltk_data"
os.makedirs(nltk_data_path, exist_ok=True)
nltk.data.path.insert(0, nltk_data_path)
os.environ['NLTK_DATA'] = nltk_data_path
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

def prepare_nltk():
    required = ['stopwords', 'punkt', 'wordnet']
    for pkg in required:
        try:
            if pkg == 'stopwords': nltk.data.find('corpora/stopwords')
            elif pkg == 'punkt': nltk.data.find('tokenizers/punkt')
            elif pkg == 'wordnet': nltk.data.find('corpora/wordnet')
            print(f"✅ {pkg} 已就绪")
        except LookupError:
            print(f"📥 正在下载 {pkg}...")
            nltk.download(pkg, download_dir=nltk_data_path)

prepare_nltk()

# 设置设备（显式指定 CPU 以避开 Torch 1.10 的兼容性 Bug）
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"🖥️ 使用设备: {device} | PyTorch版本: {torch.__version__}")

# ==================== 2. 模型加载 (优化内存) ====================
def load_spacy_model():
    try:
        # 禁用不需要的组件（Parser和NER），极大节省内存和计算时间
        nlp_model = spacy.load("en_core_web_sm", disable=["parser", "ner"])
        print(f"[成功] 已加载 spaCy 模型 (sm) 版本: {nlp_model.meta['version']}")
        return nlp_model
    except Exception as e:
        print(f"[错误] 无法加载 spaCy: {e}")
        exit(1)

nlp = load_spacy_model()
stop_words = set(stopwords.words('english'))

# ==================== 3. 辅助函数 ====================
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def preprocess_text(text):
    if not isinstance(text, str): return ""
    text = re.sub(r"&lt;|&gt;|\d+|[^a-zA-Z\s]", " ", text).lower()
    # spaCy 词形还原
    doc = nlp(text)
    words = [token.lemma_ for token in doc if token.lemma_ not in stop_words and len(token.lemma_) > 1]
    return " ".join(words)

# ==================== 4. 主实验逻辑 ====================
if __name__ == '__main__':
    set_seed(42)
    global_start = time.time()
    
    target_projects = ['Ambari','Camel','Wicket','Derby']
    # 路径请确保正确
    keyword_file = "/home/wangjq/yanjiusheng_wjq/Semantic_Compensation_Capability/KG_guochengzhong_Keyword_classification_across_all_projects.xlsx"
    output_root = "/home/wangjq/yanjiusheng_wjq/Semantic_Compensation_Capability/results-all-minilm-l6-v2/"
    os.makedirs(output_root, exist_ok=True)

    # 加载 Embedding 模型 (显式指定设备)
    print("📥 正在加载 SentenceTransformer 模型...")
    # 注意：如果此处报错，请确保已 pip install sentence-transformers
    model_path = "/home/wangjq/yanjiusheng_wjq/Semantic_Compensation_Capability/all-MiniLM-L6-v2"
    print("正在加载模型...")
    model = SentenceTransformer(
        model_path,
        device=device
    )
    print("✅ 向量模型加载完成")

    for idx, project in enumerate(target_projects, 1):
        print(f"\n{'='*30}\n🚀 项目 {idx}/{len(target_projects)}: {project}")
        
        # 1. 读取领域关键词 (3.3节 语义映射)
        try:
            df_kw = pd.read_excel(keyword_file, sheet_name=f"目标域{project}")
            keywords = df_kw["keyword"].dropna().astype(str).tolist()
            project_text = " ".join(keywords)
            project_embedding = model.encode([project_text], normalize_embeddings=True)
        except Exception as e:
            print(f"❌ 读取关键词失败: {e}")
            continue

        # 2. 读取项目数据 (3.4节 识别任务)
        data_path = f"/home/wangjq/yanjiusheng_wjq/dataset/{project}.csv"
        if not os.path.exists(data_path):
            print(f"❌ 找不到数据文件: {data_path}"); continue
            
        # 根据你的论文表3-3，这里选取后800条左右作为测试
        df_test = pd.read_csv(data_path).tail(800).copy()
        df_test['combined_text'] = df_test['summary'].fillna('') + ' ' + df_test['description'].fillna('')
        
        # 3. 文本预处理
        tqdm.pandas(desc=f"🧹 {project} Preprocessing")
        df_test['clean_text'] = df_test['combined_text'].progress_apply(preprocess_text)

        # 4. 生成向量 (关键：调小 Batch Size 防止 Killed)
        print(f"🚦 生成向量中 (Batch Size=16)...")
        text_embeddings = model.encode(
            df_test['clean_text'].tolist(), 
            batch_size=16, 
            show_progress_bar=True, 
            normalize_embeddings=True
        )

        # 5. 相似度计算与分类
        sims = cosine_similarity(text_embeddings, project_embedding).flatten()
        # 映射公式：Prob = 1 / (1 + exp(-alpha * (sim - threshold)))
        # 这里简化处理，直接用相似度分值配合 0.5 阈值
        alpha = 10.0
        prob_1 = 1 / (1 + np.exp(-alpha * sims))
        threshold = 0.5
        pred_label = (prob_1 >= threshold).astype(int)
        trues = df_test['Security'].astype(int).values

        # 6. 计算指标 (用于填入论文表)
        # p = precision_score(trues, pred_label, zero_division=0)
        # r = recall_score(trues, pred_label, zero_division=0)
        # f1 = f1_score(trues, pred_label, zero_division=0)

        # print(f"📊 实验结果统计 ({project}):")
        # print(f"   Precision: {p:.4f} | Recall: {r:.4f} | F1: {f1:.4f}")

        # 7. 保存结果
        res_df = pd.DataFrame({
            'summary': df_test['summary'],
            'description': df_test['description'],
            'true_label': trues,
            'sim_score': sims,
            'prob_1':prob_1,
            'pred_label': pred_label,
            
        })
        res_df.to_csv(f"{output_root}/{project}_results1.csv", index=False)
        
        # 8. 内存清理 (防止下一个项目运行时 Killed)
        del text_embeddings, df_test, res_df
        gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()

    print(f"\n✨ 所有实验完成！总耗时: {(time.time()-global_start)/60:.2f} 分钟")