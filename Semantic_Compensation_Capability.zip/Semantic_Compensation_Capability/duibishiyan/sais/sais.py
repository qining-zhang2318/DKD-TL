import pandas as pd
import numpy as np
import re
import nltk
import os
import time
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from sklearn.svm import SVC
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
from sklearn.utils import resample

# ==================== NLTK环境配置 ====================
nltk_data_path = "nltk_data"
os.makedirs(nltk_data_path, exist_ok=True)
nltk.data.path.insert(0, nltk_data_path)
os.environ['NLTK_DATA'] = nltk_data_path
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

def prepare_nltk():
    required = ['stopwords', 'punkt', 'wordnet']
    for pkg in required:
        try:
            if pkg == 'stopwords': nltk.data.find('corpora/stopwords')
            elif pkg == 'punkt': nltk.data.find('tokenizers/punkt')
            elif pkg == 'wordnet': nltk.data.find('corpora/wordnet')
            print(f"✅ {pkg} 已就绪")
        except LookupError:
            print(f"📥 正在下载 {pkg}...")
            nltk.download(pkg, download_dir=nltk_data_path)

prepare_nltk()
stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()
print("✅ NLTK环境配置完成！")

# -------------------------- 1. 数据加载（严格保留800条未标注集，避免清洗丢失） --------------------------
def load_combined_data(combined_path, labeled_rows=200, unlabeled_rows=800):
    step_start = time.time()
    print(f"\n【步骤1/6】加载数据（初始200条固定，未标注集严格800条）...")
    combined_data = pd.read_csv(combined_path)
    print(f"  - 原始数据总行数：{len(combined_data)}")

    if 'Security' not in combined_data.columns:
        raise ValueError("数据必须包含'security'列（1=SBR，0=NSBR）")
    combined_data['true_label'] = combined_data['Security'].astype(int)

    # 合并文本列（保留空文本，避免清洗丢失行数）
    combined_data['summary'] = combined_data['summary'].fillna('')
    combined_data['description'] = combined_data['description'].fillna('')
    combined_data['text'] = combined_data['summary'] + ' ' + combined_data['description']
    # 仅过滤完全空的文本（避免过度清洗）
    combined_data = combined_data[combined_data['text'].str.strip() != ''].reset_index(drop=True)

    # 严格拆分：初始200条标注集 + 接下来800条未标注集（强制取800条）
    if len(combined_data) < labeled_rows + unlabeled_rows:
        raise ValueError(f"数据总行数不足！需要至少{labeled_rows+unlabeled_rows}条（200+800）")
    
    # 初始标注集（200条，标签固定）
    initial_labeled_data = combined_data.iloc[:labeled_rows].copy()[['text', 'true_label']].rename(columns={'true_label': 'label'}).reset_index(drop=True)
    # 未标注集（严格800条，初始标签UNLABELED=-1）
    unlabeled_data = combined_data.iloc[labeled_rows:labeled_rows+unlabeled_rows].copy()[['text', 'true_label']].reset_index(drop=True)
    unlabeled_data['prev_label'] = -1  # 上一轮标签（初始UNLABELED）
    unlabeled_data['current_label'] = -1  # 本轮标签

    # 打印数据分布
    sbr_initial = sum(initial_labeled_data['label'] == 1)
    nsbr_initial = sum(initial_labeled_data['label'] == 0)
    sbr_unlabeled = sum(unlabeled_data['true_label'] == 1)
    nsbr_unlabeled = sum(unlabeled_data['true_label'] == 0)

    print(f"✅ 步骤1完成（耗时{time.time()-step_start:.2f}秒）")
    print(f"  - 初始标注集L0（永久固定）：{len(initial_labeled_data)}行（SBR：{sbr_initial}，NSBR：{nsbr_initial}）")
    print(f"  - 未标注集U（严格800条）：{len(unlabeled_data)}行（真实SBR：{sbr_unlabeled}，真实NSBR：{nsbr_unlabeled}）")
    return initial_labeled_data, unlabeled_data, combined_data

# -------------------------- 2. TF-IDF 关键词挖掘 --------------------------
def calculate_category_tf(docs, all_words):
    """
    计算论文中的类别级 TF:
    TF(w, C) = 词w在类别C中出现的总次数
    """
    tf_dict = {word: 0 for word in all_words}
    
    for doc in docs:
        for word in doc:
            if word in tf_dict:
                tf_dict[word] += 1
    
    return tf_dict

def calculate_category_idf(target_docs, opposite_docs, all_words):
    """
    计算论文中的改进版 IDF:
    IDF(w, C_opposite) = log( (1 + |C_opp|) / (1 + 包含词w的对立类别文档数) )
    """
    idf_dict = {}
    n_opp = len(opposite_docs)
    
    for word in list(all_words):
        # 计算该词在对立类别中出现的文档数量
        docs_with_word = sum(1 for doc in opposite_docs if word in doc)
        # 论文逻辑：在对立类中越稀少，对目标类的判别力越高
        idf = np.log((1 + n_opp) / (1 + docs_with_word))
        idf_dict[word] = idf
    return idf_dict

def mine_security_keywords(current_labeled_data, cve_data=None, top_k=100):
    step_start = time.time()
    print("  - 挖掘安全关键词（论文TF-IDF区分性权重）...")

    sbr_docs = current_labeled_data[current_labeled_data['label'] == 1]['text_pre'].tolist()
    nsbr_docs = current_labeled_data[current_labeled_data['label'] == 0]['text_pre'].tolist()
    print(f"    > 关键词挖掘基础：当前标注集SBR文档数{len(sbr_docs)}，NSBR文档数{len(nsbr_docs)}")

    # SD (Security Documents) = 项目SBR + CVE外部知识
    SD = sbr_docs.copy()
    if cve_data is not None and len(cve_data) > 0:
        # 论文：随机采样与NSBR数量相同的CVE数据
        cve_sampled = resample(cve_data, n_samples=len(nsbr_docs), random_state=42)
        SD += cve_sampled
        print(f"    - 融合CVE数据（采样{len(cve_sampled)}条）")
    NSD = nsbr_docs.copy() # Non-Security Documents

    # 获取词汇表
    all_words = set([word for doc in (SD + NSD) for word in doc])
    if not all_words:
        raise ValueError("预处理后无有效词汇")

    # 2. 计算 SBR 类别的权重 (Equation 1-5 in paper)
    # W_sbr(w) = TF(w, SD) * IDF(w, NSD)
    sd_tf = calculate_category_tf(SD, all_words)
    sd_idf = calculate_category_idf(SD, NSD, all_words) # 使用对立类的稀疏度
    
    W_sbr = {word: sd_tf[word] * sd_idf[word] for word in all_words}
    
    # 3. 计算 NSBR 类别的权重
    # W_nsbr(w) = TF(w, NSD) * IDF(w, SD)
    nsd_tf = calculate_category_tf(NSD, all_words)
    nsd_idf = calculate_category_idf(NSD, SD, all_words)
    
    W_nsbr = {word: nsd_tf[word] * nsd_idf[word] for word in all_words}
    
    # 4. 计算判别权重 (Equation 6 in paper)
    # discriminative_weight(t) = tfidf(t, SD) / tfidf(t, NSD)
    disc_weight = {}
    for word in all_words:
        # 使用比值法（Ratio）体现判别力，同时处理分母为0
        denominator = W_nsbr[word] if W_nsbr[word] > 0 else 1e-10
        disc_weight[word] = W_sbr[word] / denominator

    # 5. 提取 Top-K
    top_keywords = sorted(disc_weight.items(), key=lambda x: x[1], reverse=True)[:top_k]
    keywords = [word for word, _ in top_keywords]

    print(f"✅ 关键词挖掘完成（耗时{time.time()-step_start:.2f}秒）")
    print(f"    - Top{top_k}关键词示例：{keywords[:10]}...")
    return keywords

# -------------------------- 3. 仅精炼新增扩充的样本 --------------------------
def refine_new_samples(new_samples, keywords):
    """仅精炼新增扩充的样本，初始200条不参与"""
    step_start = time.time()
    print("  - 精炼新增扩充样本：过滤无关键词的SBR...")
    refined_data = []
    sbr_before = sum(new_samples['label'] == 1)
    downgrade_count = 0

    for _, row in new_samples.iterrows():
        text_pre = row['text_pre']
        label = row['label']
        if label == 0:
            refined_data.append(row)  # NSBR直接保留
        else:
            # 仅对新增SBR样本做关键词校验
            has_keyword = any(word in text_pre for word in keywords)
            if has_keyword:
                refined_data.append(row)
            else:
                row['label'] = 0
                refined_data.append(row)
                downgrade_count += 1

    refined_df = pd.DataFrame(refined_data)
    sbr_after = sum(refined_df['label'] == 1)
    print(f"✅ 新增样本精炼完成（耗时{time.time()-step_start:.2f}秒）")
    print(f"    > 新增样本精炼详情: {sbr_before} 个 SBR 样本中，{downgrade_count} 个因无关键词降级为 NSBR")
    return refined_df

# -------------------------- 4. 特征构建 --------------------------
def build_feature_vectors(data, keywords):
    step_start = time.time()
    print(f"  - 构建特征向量（关键词数：{len(keywords)}）...")
    features = []
    for _, row in data.iterrows():
        text_pre = row['text_pre']
        vec = [1 if word in text_pre else 0 for word in keywords]
        features.append(vec)
    print(f"✅ 特征构建完成（耗时{time.time()-step_start:.2f}秒）")
    return np.array(features)

# -------------------------- 5. 文本预处理 --------------------------
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    words = nltk.word_tokenize(text)
    words = [stemmer.stem(word) for word in words if word not in stop_words and len(word) > 2]
    return words

# -------------------------- 6. SAIS 主迭代（保证新增800条，修正去重逻辑） --------------------------
def SAIS_paper_implementation(combined_path, cve_path, labeled_rows=200, unlabeled_rows=800, top_k=100, max_iter=10, threshold=0.5):
    # 加载数据：严格200条标注 + 800条未标注
    initial_labeled_data, unlabeled_data, combined_data = load_combined_data(
        combined_path, labeled_rows=labeled_rows, unlabeled_rows=unlabeled_rows
    )
    # 预处理初始200条文本（仅做预处理，标签不变）
    initial_labeled_data['text_pre'] = initial_labeled_data['text'].apply(preprocess_text)
    # 当前标注集 = 初始200条（固定）
    current_labeled_data = initial_labeled_data.copy()

    # 加载CVE辅助集
    step2_start = time.time()
    print(f"\n【步骤2/6】加载CVE辅助集...")
    cve = pd.read_csv(cve_path)
    cve = cve.dropna(subset=['Summary']).reset_index(drop=True)
    cve['text'] = cve['Summary'].fillna('')
    cve['text_pre'] = cve['text'].apply(preprocess_text)
    cve_text_pre = cve['text_pre'].tolist()
    print(f"✅ CVE加载完成（有效行数：{len(cve)}）")

    # 预处理未标注集文本（800条全部保留）
    print(f"\n【步骤3/6】预处理未标注集文本（800条全部保留）...")
    unlabeled_data['text_pre'] = unlabeled_data['text'].apply(preprocess_text)
    print(f"✅ 未标注集预处理完成，行数：{len(unlabeled_data)}")

    # 初始化变量
    final_model = None
    security_keywords = []
    iter_metrics = []
    total_iter_start = time.time()

    print(f"\n【步骤4/6】SAIS迭代训练（收敛条件：未标注集标签无变化）...")
    for iter_num in range(1, max_iter+1):
        print(f"\n===== 迭代 {iter_num}/{max_iter}（top_k={top_k}） =====")
        print(f"  > 当前标注集规模：{len(current_labeled_data)}行（初始200条+新增{len(current_labeled_data)-200}条）")

        # 1. 关键词挖掘（基于当前标注集）
        if iter_num == 1:
            print(f" 【子步骤1/7】第一轮关键词挖掘（融合CVE）")
            keywords = mine_security_keywords(current_labeled_data, cve_text_pre, top_k=top_k)
        else:
            print(f" 【子步骤1/7】第{iter_num}轮关键词挖掘（仅用当前标注集）")
            keywords = mine_security_keywords(current_labeled_data, top_k=top_k)
        security_keywords = keywords

        # 2. 构建当前标注集特征 + 训练SVM
        print(f" 【子步骤2/7】训练SVM模型（初始200条标签固定）")
        X_labeled = build_feature_vectors(current_labeled_data, keywords)
        y_labeled = current_labeled_data['label'].values
        if len(np.unique(y_labeled)) < 2:
            print("❌ 标注集标签单一，停止迭代（论文终止条件）")
            break

        model = SVC(kernel='linear', probability=True, random_state=42, class_weight='balanced')
        model.fit(X_labeled, y_labeled)
        final_model = model

        # 3. 预测未标注集U（输出SBR概率，阈值0.5划分标签）
        print(f" 【子步骤3/7】预测未标注集U（800条，阈值{threshold}）")
        X_unlabeled = build_feature_vectors(unlabeled_data, keywords)
        # 输出SBR的概率（论文要求的likelihood）
        sbr_prob = model.predict_proba(X_unlabeled)[:, 1]
        # 按阈值划分标签：>0.5=SBR(1)，≤0.5=NSBR(0)
        current_pred_labels = [1 if prob > threshold else 0 for prob in sbr_prob]
        # 更新未标注集的「本轮标签」
        unlabeled_data['current_label'] = current_pred_labels

        # 4. 计算本轮指标（基于未标注集真实标签）
        print(f" 【子步骤4/7】计算本轮性能指标")
        y_true = unlabeled_data['true_label'].values
        y_pred = np.array(current_pred_labels)
        p = precision_score(y_true, y_pred, pos_label=1, zero_division=0)
        r = recall_score(y_true, y_pred, pos_label=1, zero_division=0)
        f1 = f1_score(y_true, y_pred, pos_label=1, zero_division=0)
        cm = confusion_matrix(y_true, y_pred, labels=[0,1])
        tn, fp, fn, tp = cm[0][0], cm[0][1], cm[1][0], cm[1][1]

        print(f"  - 本轮800条未标注集指标：")
        print(f"    → SBR概率阈值：{threshold}")
        print(f"    → Precision={p:.4f}, Recall={r:.4f}, F1={f1:.4f}")
        print(f"    → 混淆矩阵：TN={tn}, FP={fp}, FN={fn}, TP={tp}")

        # 保存本轮指标
        iter_metrics.append({
            'iter': iter_num, 'precision': p, 'recall': r, 'f1': f1,
            'tn': tn, 'fp': fp, 'fn': fn, 'tp': tp,
            'labeled_size': len(current_labeled_data),
            'sbr_prob_threshold': threshold,
            'top_k': top_k  # 新增top_k字段，便于汇总
        })

        # 5. 检查未标注集标签是否变化（论文核心收敛条件）
        print(f" 【子步骤5/7】检查未标注集标签变化（收敛判断）")
        # 对比「本轮标签」和「上一轮标签」
        label_changed = (unlabeled_data['current_label'] != unlabeled_data['prev_label']).any()
        changed_count = (unlabeled_data['current_label'] != unlabeled_data['prev_label']).sum()
        print(f"  - 未标注集标签变化统计：{changed_count} 条BR标签发生变化（总{len(unlabeled_data)}条）")

        if not label_changed:
            print("✅ 所有未标注BR的标签均无变化，模型收敛，停止迭代（论文收敛条件）")
            break

        # 6. 准备扩充数据：800条自动标注的未标注集（全部保留）
        print(f" 【子步骤6/7】准备自动标注数据（800条全部保留）")
        auto_labeled_candidate = unlabeled_data.copy()[['text', 'current_label', 'text_pre']]
        auto_labeled_candidate.rename(columns={'current_label': 'label'}, inplace=True)
        print(f"  - 自动标注候选样本数：{len(auto_labeled_candidate)}条（严格800条）")

        # 7. 精炼新增候选样本 + 扩充标注集（仅过滤新增样本内部重复）
        print(f" 【子步骤7/7】精炼新增样本并扩充标注集（初始200条不变）")
        # 仅精炼新增候选样本
        refined_new_samples = refine_new_samples(auto_labeled_candidate, keywords)
        # 仅过滤新增样本内部重复（不过滤与初始200条的重复，保证800条）
        refined_new_samples = refined_new_samples.drop_duplicates(subset=['text']).reset_index(drop=True)
        duplicate_count = len(auto_labeled_candidate) - len(refined_new_samples)
        print(f"  - 新增样本内部重复数：{duplicate_count}条（已过滤）")

        # 合并：初始200条（固定） + 精炼后的新增样本（保证800条）
        new_labeled = pd.concat([
            initial_labeled_data[['text', 'label', 'text_pre']],  # 初始200条，标签固定
            refined_new_samples[['text', 'label', 'text_pre']]   # 新增精炼样本（≈800条）
        ], ignore_index=True)
        current_labeled_data = new_labeled.copy()

        # 打印扩充详情（明确新增数量）
        new_added = len(current_labeled_data) - 200
        print(f"  - 标注集扩充完成：{len(current_labeled_data)}行（初始200条+新增{new_added}条）")
        if new_added != 800:
            print(f"  > 备注：新增{new_added}条（目标800条），差异原因：新增样本内部重复{duplicate_count}条 + 精炼降级{len(auto_labeled_candidate)-len(refined_new_samples)-duplicate_count}条")
        else:
            print(f"  > 新增数量符合预期：800条！")

        # 更新未标注集的「上一轮标签」为「本轮标签」，进入下一轮
        unlabeled_data['prev_label'] = unlabeled_data['current_label'].copy()
        print(f"  > 未标注集标签已更新，进入下一轮迭代")

    # 结果整理与保存
    total_time = time.time() - total_iter_start
    print("\n========== SAIS 执行完成（严格对齐论文逻辑） ==========")
    print(f"总耗时：{total_time:.2f}秒 | 实际迭代轮次：{len(iter_metrics)}")
    print(f"最终标注集规模：{len(current_labeled_data)}行（初始200条+新增{len(current_labeled_data)-200}条）")
    
    # 输出最终识别的SBRs（论文要求）
    final_sbrs = unlabeled_data[unlabeled_data['current_label'] == 1]['text'].tolist()
    print(f"\n【论文最终输出】识别出的SBR数量：{len(final_sbrs)} 条")
    print(f"  > 前5条SBR示例：{[text[:50]+'...' for text in final_sbrs[:5]]}")

    # 保存结果（文件名加入top_k，避免覆盖）
    metrics_df = pd.DataFrame(iter_metrics)
    metrics_df.to_csv(f"Ambari_SAIS_paper_converge_metrics_topk_{top_k}.csv", index=False)
    # 保存最终识别的SBRs
    final_sbrs_df = pd.DataFrame({
        'sbr_text': final_sbrs,
        'true_label': unlabeled_data[unlabeled_data['current_label'] == 1]['true_label'].values,
        'top_k': top_k
    })
    final_sbrs_df.to_csv(f"Ambari_SAIS_identified_SBRs_topk_{top_k}.csv", index=False)

    print(f"\n【论文核心指标汇总（top_k={top_k}）】")
    print(metrics_df[['iter', 'precision', 'recall', 'f1', 'tn', 'fp', 'fn', 'tp']])

    # 最优轮次（F1最高）：新增混淆矩阵字段
    best_info = None
    if len(metrics_df) > 0:
        best_iter = metrics_df.loc[metrics_df['f1'].idxmax()]
        best_info = {
            'top_k': top_k,
            'best_iter': int(best_iter['iter']),
            'best_f1': best_iter['f1'],
            'best_precision': best_iter['precision'],
            'best_recall': best_iter['recall'],
            'tn': int(best_iter['tn']),    # 最优轮次TN
            'fp': int(best_iter['fp']),    # 最优轮次FP
            'fn': int(best_iter['fn']),    # 最优轮次FN
            'tp': int(best_iter['tp']),    # 最优轮次TP
            'total_time': total_time,
            'final_sbr_count': len(final_sbrs)
        }
        print(f"\n【论文最优轮次】第{int(best_iter['iter'])}轮")
        print(f"最优F1：{best_iter['f1']:.4f} | Precision：{best_iter['precision']:.4f} | Recall：{best_iter['recall']:.4f}")
        print(f"最优轮次混淆矩阵：TN={best_iter['tn']}, FP={best_iter['fp']}, FN={best_iter['fn']}, TP={best_iter['tp']}")

    return current_labeled_data, metrics_df, security_keywords, final_sbrs, best_info

# -------------------------- 主函数（遍历top_k 10-100） --------------------------
if __name__ == "__main__":
    # 配置路径
    A_CSV_PATH = "/home/wangjq/yanjiusheng_wjq/dataset/Wicket.csv"
    CVE_CSV_PATH = "/home/wangjq/yanjiusheng_wjq/Semantic_Compensation_Capability/duibishiyan/sais/CVE.csv"

    # 定义要遍历的top_k列表（10到100，步长10）
    top_k_list = [50]
    # 保存所有top_k的最优结果，便于后续对比
    all_best_results = []

    try:
        print("="*80 + " SAIS框架（遍历top_k 10-100） " + "="*80)
        # 逐个运行每个top_k
        for idx, top_k in enumerate(top_k_list):
            print(f"\n\n{'='*60} 开始运行 top_k={top_k}（{idx+1}/{len(top_k_list)}） {'='*60}")
            # 执行当前top_k的实验
            final_labeled, metrics, keywords, final_sbrs, best_info = SAIS_paper_implementation(
                combined_path=A_CSV_PATH,
                cve_path=CVE_CSV_PATH,
                labeled_rows=200,
                unlabeled_rows=800,
                top_k=top_k,  # 传入当前top_k
                max_iter=10,
                threshold=0.5
            )
            # 保存当前top_k的最优结果
            if best_info is not None:
                all_best_results.append(best_info)
            print(f"\n{'='*60} top_k={top_k} 运行完成 {'='*60}")
        
        # 保存所有top_k的最优结果汇总表（含混淆矩阵）
        if all_best_results:
            all_best_df = pd.DataFrame(all_best_results)
            all_best_df.to_csv("Wicket_SAIS_all_topk_best_results.csv", index=False)
            print("\n\n" + "="*80 + " 所有top_k运行完成 " + "="*80)
            print("📊 各top_k最优结果汇总（含混淆矩阵）：")
            # 展示包含混淆矩阵的汇总表
            display_cols = ['top_k', 'best_f1', 'best_precision', 'best_recall', 
                            'tn', 'fp', 'fn', 'tp', 'final_sbr_count']
            print(all_best_df[display_cols].to_string(index=False))
        
    except Exception as e:
        print(f"\n❌ 执行出错：{type(e).__name__} - {str(e)}")
        import traceback
        traceback.print_exc()